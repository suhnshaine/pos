<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index()
    {
        return 'This is the landing page.';
    }

    public function about()
    {
        return 'This is the about page.';
    }
}